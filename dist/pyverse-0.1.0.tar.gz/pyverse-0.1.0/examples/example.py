import pyverse

print(pyverse.add(2, 3))  # should print 5

win = pyverse.Window("Hello", 800, 600)
win.show()